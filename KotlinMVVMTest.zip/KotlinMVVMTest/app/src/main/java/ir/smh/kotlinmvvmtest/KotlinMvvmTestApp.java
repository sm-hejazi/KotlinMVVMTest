package ir.smh.kotlinmvvmtest;

import android.app.Application;

import androidx.appcompat.app.AppCompatActivity;

import javax.inject.Inject;

import dagger.android.AndroidInjector;
import dagger.android.DispatchingAndroidInjector;
import dagger.android.HasActivityInjector;
import ir.i3p.freight.di.component.DaggerAppComponent;
import uk.co.chrisjenx.calligraphy.CalligraphyConfig;

/**
 * Created by m.hejazi on 5/7/18.
 */

public class KotlinMvvmTestApp extends Application implements HasActivityInjector {
    private static KotlinMvvmTestApp instance;
    private boolean login = true;


    @Inject
    DispatchingAndroidInjector<AppCompatActivity> activityDispatchingAndroidInjector;

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;


        DaggerAppComponent.builder()
                .application(this)
                .build()
                .inject(this);

        CalligraphyConfig.initDefault(new CalligraphyConfig.Builder()
                .setDefaultFontPath("fonts/IRANSansMobile.ttf")
//                .setFontAttrId(R.attr.fontPath)
                .build()
        );

        initKianApp();
    }

    private void initKianApp() {

    }

    public static KotlinMvvmTestApp getInstance() {
        return instance;
    }


    @Override
    public AndroidInjector<AppCompatActivity> activityInjector() {
        return activityDispatchingAndroidInjector;
    }

    public boolean isLogin() {
        return login;
    }

    public void setLogin(boolean login) {
        this.login = login;
    }
}
