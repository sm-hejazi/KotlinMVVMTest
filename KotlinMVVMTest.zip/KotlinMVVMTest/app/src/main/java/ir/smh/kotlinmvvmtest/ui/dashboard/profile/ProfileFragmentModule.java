package ir.smh.kotlinmvvmtest.ui.dashboard.profile;

import dagger.Module;
import dagger.Provides;
import ir.i3p.freight.data.local.preference.AppPreferencesHelper;
import ir.i3p.freight.data.repository.dashboard.profile.ProfileRepository;
import ir.i3p.freight.data.repository.dashboard.profile.ProfileRepositoryFactory;
import ir.i3p.freight.data.repository.dashboard.profile.ProfileRepositoryImpl;

/**
 * Created by m.hejazi on 5/14/18.
 */
@Module
public class ProfileFragmentModule {


    @Provides
    ProfileRepository provideUserRepository(ProfileRepositoryFactory repositoryFactory, AppPreferencesHelper appPreferencesHelper) {
        return new ProfileRepositoryImpl(repositoryFactory, appPreferencesHelper);
    }
}
