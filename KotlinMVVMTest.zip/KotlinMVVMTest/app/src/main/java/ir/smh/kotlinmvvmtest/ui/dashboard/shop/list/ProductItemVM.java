package ir.smh.kotlinmvvmtest.ui.dashboard.shop.list;

import android.databinding.BaseObservable;
import android.databinding.ObservableBoolean;

import ir.i3p.freight.data.model.shop.CargoModel;

public class ProductItemVM extends BaseObservable {

    private CargoModel product;
    private ObservableBoolean isMyShop = new ObservableBoolean(false);


    public CargoModel getProduct() {
        return product;
    }

    public ProductItemVM(CargoModel responseProductModel, boolean isMyShop) {
        this.isMyShop.set(isMyShop);
        setProduct(responseProductModel);
    }


    public void setProduct(CargoModel responseProductModel) {
        product = responseProductModel;
    }

    public ObservableBoolean getIsMyShop() {
        return isMyShop;
    }

    public String cityIdToName(int id) {
        return "";
    }
}
