package ir.smh.kotlinmvvmtest.ui.dashboard;

import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.MenuItem;

import com.aurelhubert.ahbottomnavigation.AHBottomNavigation;
import com.aurelhubert.ahbottomnavigation.AHBottomNavigationItem;
import com.ppp_smh.initlibrary.ui.base.BaseActivity;

import javax.inject.Inject;

import dagger.android.AndroidInjector;
import dagger.android.DispatchingAndroidInjector;
import dagger.android.support.HasSupportFragmentInjector;
import ir.i3p.freight.R;
import ir.i3p.freight.databinding.ActivityDashboardBinding;
import ir.i3p.freight.ui.dashboard.shop.ShopFragment;


public class DashboardActivity extends BaseActivity<DashboardVM> implements HasSupportFragmentInjector {

    @Inject
    DispatchingAndroidInjector<Fragment> fragmentDispatchingAndroidInjector;
    private AHBottomNavigation bottomNavigation;

    @Inject
    DashboardVM dashboardViewModel;
    private ActivityDashboardBinding activityDashboardBinding;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activityDashboardBinding = DataBindingUtil.setContentView(this, R.layout.activity_dashboard);
        setContentView(activityDashboardBinding.getRoot());
        setBaseVM(dashboardViewModel);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        super.onOptionsItemSelected(item);
        ShopFragment shopFragment = dashboardViewModel.getCurrentFragment("market");
        if (shopFragment != null && shopFragment.isVisible())
            shopFragment.onActionClick(item);
        return true;
    }

    @Override
    public void initUI(Bundle savedInstanceState) {
        super.initUI(savedInstanceState);
        bottomNavigation = activityDashboardBinding.bottomNavigation;

        // Create items
        AHBottomNavigationItem navMarket = new AHBottomNavigationItem(getString(R.string.nav_market), R.drawable.ic_store);
        AHBottomNavigationItem navMyShop = new AHBottomNavigationItem(getString(R.string.nav_myshop), R.drawable.ic_shopping);
        AHBottomNavigationItem navAccount = new AHBottomNavigationItem(getString(R.string.nav_account), R.drawable.ic_add);
        AHBottomNavigationItem navProfile = new AHBottomNavigationItem(getString(R.string.nav_profile), R.drawable.ic_account);

        // Add items
        bottomNavigation.addItem(navMarket);
        bottomNavigation.addItem(navMyShop);
        bottomNavigation.addItem(navAccount);
        bottomNavigation.addItem(navProfile);

        // Set background color
        bottomNavigation.setDefaultBackgroundColor(getResources().getColor(R.color.colorBGNavigate));

        // Disable the translation inside the CoordinatorLayout
        bottomNavigation.setBehaviorTranslationEnabled(true);

        // Enable the translation of the FloatingActionButton
//        bottomNavigation.manageFloatingActionButtonBehavior(floatingActionButton);

        // Change colors
        bottomNavigation.setAccentColor(getResources().getColor(R.color.colorAccent));
        bottomNavigation.setInactiveColor(getResources().getColor(R.color.colorDivider));

        // Force to tint the drawable (useful for font with icon for example)
//        bottomNavigation.setForceTint(true);

        // Display color under navigation bar (API 21+)
        // Don't forget these lines in your style-v21
        // <item name="android:windowTranslucentNavigation">true</item>
        // <item name="android:fitsSystemWindows">true</item>
//        bottomNavigation.setTranslucentNavigationEnabled(true);

        // Manage titles
        bottomNavigation.setTitleState(AHBottomNavigation.TitleState.ALWAYS_HIDE);
//        bottomNavigation.setTitleState(AHBottomNavigation.TitleState.ALWAYS_SHOW);
//        bottomNavigation.setTitleState(AHBottomNavigation.TitleState.ALWAYS_HIDE);

        // Use colored navigation with circle reveal effect
//        bottomNavigation.setColored(true);

        // Set current item programmatically
        bottomNavigation.setCurrentItem(0);
        dashboardViewModel.openShop(false);

        // Customize notification (title, background, typeface)
//        bottomNavigation.setNotificationBackgroundColor(getResources().getColor(R.color.colorAccent));

        // Add or remove notification for each item
//        bottomNavigation.setNotification("33333 333", 3);
//        // OR
//        AHNotification notification = new AHNotification.Builder()
//                .setText("1111 11 111 11")
//                .setBackgroundColor(ContextCompat.getColor(this, R.color.colorDivider))
//                .setTextColor(ContextCompat.getColor(this, R.color.colorAccent))
//                .build();
//        bottomNavigation.setNotification(notification, 1);

        // Enable / disable item & set disable color
//        bottomNavigation.enableItemAtPosition(2);
//        bottomNavigation.disableItemAtPosition(3);
//        bottomNavigation.setItemDisableColor(getResources().getColor(R.color.colorDivider));

        // Set listeners
        bottomNavigation.setOnTabSelectedListener(new AHBottomNavigation.OnTabSelectedListener() {
            @Override
            public boolean onTabSelected(int position, boolean wasSelected) {
                switch (position) {
                    case 0:
                        dashboardViewModel.openShop(false); //Market
                        break;
                    case 1:
                        dashboardViewModel.openShop(true); //My Shop
                        break;
                    case 2:
                        dashboardViewModel.addProduct();
                        break;
                    case 3:
                        dashboardViewModel.openProfile();
                        break;
                }
                return true;
            }
        });
        bottomNavigation.setOnNavigationPositionListener(new AHBottomNavigation.OnNavigationPositionListener() {
            @Override
            public void onPositionChange(int y) {
                // Manage the new y position
            }
        });


    }

    @Override
    public DashboardVM getViewModel() {
        return dashboardViewModel;
    }

    @Override
    public AndroidInjector<Fragment> supportFragmentInjector() {
        return fragmentDispatchingAndroidInjector;
    }
}
