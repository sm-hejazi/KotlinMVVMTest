package ir.smh.kotlinmvvmtest.ui.dashboard;

import dagger.Module;
import dagger.Provides;
import ir.i3p.freight.di.scope.ActivityScope;

/**
 * Created by m.hejazi on 5/14/18.
 */
@Module
public class DashboardActivityModule {

    @Provides
    @ActivityScope
    public DashboarNavigator provideNavigator(DashboardActivity dashboardActivity) {
        return new DashboarNavigator(dashboardActivity);
    }
}
