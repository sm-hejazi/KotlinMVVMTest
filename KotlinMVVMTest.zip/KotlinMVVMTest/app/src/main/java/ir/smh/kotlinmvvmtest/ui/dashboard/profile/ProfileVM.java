package ir.smh.kotlinmvvmtest.ui.dashboard.profile;

import android.databinding.ObservableBoolean;
import android.databinding.ObservableField;
import android.support.v4.util.Pair;
import android.text.TextUtils;

import com.ppp_smh.initlibrary.entity.ErrorStatus.ErrorModel;
import com.ppp_smh.initlibrary.ui.base.BaseViewModel;
import com.ppp_smh.initlibrary.ui.base.SingleEventLiveData;
import com.ppp_smh.initlibrary.util.connectivity.BaseConnectionManager;

import java.util.HashMap;

import javax.inject.Inject;

import ir.i3p.freight.call.dashboard.profile.ProfileUseCase;
import ir.i3p.freight.data.model.user.UserModel;
import ir.i3p.freight.ui.dashboard.DashboarNavigator;
import ir.i3p.freight.util.CSVReader;


/**
 * Created by m.hejazi on 5/14/18.
 */

public class ProfileVM extends BaseViewModel {
    public SingleEventLiveData<ErrorModel> raisedError;
    public SingleEventLiveData<UserModel> startEditActivity;
    private final ProfileUseCase mUseCase;
    private ObservableField<UserModel> user;
    private ObservableField<String> fullName;
    private HashMap<Integer,String> prefixMap;
    private ObservableBoolean userComplete;

    private DashboarNavigator dashboarNavigator;

    @Inject
    public ProfileVM(BaseConnectionManager connectionManager, DashboarNavigator dashboarNavigator, ProfileUseCase mUseCase) {
        super(connectionManager, dashboarNavigator);
        this.dashboarNavigator = dashboarNavigator;
        this.mUseCase = mUseCase;
        raisedError = new SingleEventLiveData<>();
        startEditActivity = new SingleEventLiveData<>();
        user = new ObservableField<>();
        fullName = new ObservableField<>("نام نام خانوادگی");
        userComplete = new ObservableBoolean(false);
        prefixMap = new CSVReader().readMap("data_file/prefix.csv");
    }

    public void getUserWeb() {
        isLoading.set(true);
        mUseCase.execute(this::requestUserResponse, this::onTokenExpired);
    }

    private void requestUserResponse(Pair<UserModel, ErrorModel> response) {
        isLoading.set(false);
        if (response.second != null) {
            raisedError.setValue(response.second);
            return;
        }

        setUser(response.first);
    }

    @Override
    public void clearUseCaseDisposables() {
        mUseCase.dispose();
    }

    public ObservableBoolean getIsLoading() {
        return isLoading;
    }

    public ObservableField<String> getFullName() {
        return fullName;
    }

    public ObservableField<UserModel> getUser() {
        return user;
    }

    public void setUser(UserModel user) {
        this.user.set(user);
        if (user.getPrefix() != null && user.getPrefix() > 0)
            fullName.set(prefixMap.get(user.getPrefix()) + " " + user.getFirstname() + " " + user.getLastname());
        setUserComplete(!TextUtils.isEmpty(user.getFirstname()) &&
                !TextUtils.isEmpty(user.getLastname()) &&
                !TextUtils.isEmpty(user.getMobile()) &&
                !TextUtils.isEmpty(user.getEmail()) &&
                !TextUtils.isEmpty(user.getNationalCode()));
    }

    public ObservableBoolean getUserComplete() {
        return userComplete;
    }

    public void setUserComplete(Boolean userComplete) {
        this.userComplete.set(userComplete);
    }

    public void eidtAction(){
        startEditActivity.setValue(user.get());
    }
}
