package ir.smh.kotlinmvvmtest.ui.dashboard.shop.list;

import android.databinding.DataBindingUtil;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import ir.i3p.freight.R;
import ir.i3p.freight.data.model.shop.CargoModel;
import ir.i3p.freight.databinding.ProductItemBinding;
import ir.i3p.freight.ui.dashboard.shop.ShopVM;
import ir.i3p.freight.util.CSVReader;

public class ShopAdapter extends
        RecyclerView.Adapter<ShopAdapter.MyViewHolder> {

    private List<CargoModel> products;
    private final ShopVM mViewModel;
    private final boolean isMyShop;
    private HashMap<Integer,String> cityMap;
    private HashMap<Integer,String> stateMap;

    public ShopAdapter(ShopVM mViewModel, boolean isMyShop) {
        this.isMyShop = isMyShop;
        this.products = new ArrayList<>();
        this.mViewModel = mViewModel;
        cityMap = new CSVReader().readMap("data_file/city.csv");
        stateMap = new CSVReader().readMap("data_file/state.csv");
    }

    public void deleteAll() {
        products.clear();
        notifyDataSetChanged();
    }

    public void setProducts(@NonNull List<CargoModel> products) {
        this.products = products;
        notifyDataSetChanged();
    }

    public void addMoreProducts(@NonNull List<CargoModel> products) {
        if (products.size() > 0)
            this.products.addAll(this.products.size(),products);
        notifyDataSetChanged();
    }

    public void addNewProduct(@NonNull List<CargoModel> products) {
        if (products.size() > 0)
            this.products.add(0,products.get(0));
        notifyDataSetChanged();
    }

    public void updateProduct(@NonNull List<CargoModel> products) {
        if (products.size() > 0)
            this.products.set(findPos(products.get(0).getId()),products.get(0));
        notifyDataSetChanged();
    }

    public void setProduct(CargoModel products) {
        this.products.add(products);
        notifyDataSetChanged();
    }

    public void updateProduct(int id, CargoModel product) {
        int pos = findPos(id);
        this.products.set(pos, product);
        notifyDataSetChanged();
    }

    public void deleteProduct(int id) {
        int pos = findPos(id);
        this.products.remove(pos);
        notifyDataSetChanged();
    }

    private int findPos(int id) {
        int pos = 0;
        for (int i = 0; i < this.products.size(); i++) {
            if (this.products.get(i).getId() == id) {
                pos = i;
                break;
            }
        }
        return pos;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        ProductItemBinding itemLayoutBinding = DataBindingUtil
                .inflate(LayoutInflater.from(parent.getContext()),
                        R.layout.product_item, parent, false);
        return new MyViewHolder(itemLayoutBinding);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        CargoModel product = products.get(position);
        product.setSource(stateMap.get(product.getFirstOstanCId()) + " - " + cityMap.get(product.getFirstCityCId()));
        product.setDestination(stateMap.get(product.getLastOstanCId())  + " - " + cityMap.get(product.getLastCityCId()));

        ProductItemVM productItemVM = new ProductItemVM(product, isMyShop);
        holder.itemLayoutBinding.item.setOnClickListener(v -> mViewModel.detailProduct(products.get(position)));

        holder.itemLayoutBinding.repeat.setOnClickListener(v -> mViewModel.repeatCargo(products.get(position)));
        holder.itemLayoutBinding.edit.setOnClickListener(v -> mViewModel.editCargo(products.get(position)));
        holder.itemLayoutBinding.remove.setOnClickListener(v -> mViewModel.removeCargo(products.get(position)));
//        holder.itemLayoutBinding.exist.setOnCheckedChangeListener((compoundButton, b) -> {
//            if (compoundButton.isPressed()) {
//                mViewModel.updateProductExist(compoundButton, products.get(position).getId(), b);
//            }
//        });
        holder.setProductItemVM(productItemVM);
    }

    @Override
    public int getItemCount() {
        return products.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        ProductItemBinding itemLayoutBinding;

        MyViewHolder(ProductItemBinding listItemLayoutBinding) {
            super(listItemLayoutBinding.getRoot());
            this.itemLayoutBinding = listItemLayoutBinding;
        }

        //fill each list item with Observable items(id,name,family)
        void setProductItemVM(ProductItemVM productItemVM) {
            itemLayoutBinding.setItemVM(productItemVM);
            itemLayoutBinding.executePendingBindings();
        }

    }
}
