package ir.smh.kotlinmvvmtest.ui.dashboard;

import com.ppp_smh.initlibrary.util.navigator.BaseNavigator;

import java.lang.ref.WeakReference;

import ir.i3p.freight.R;
import ir.i3p.freight.ui.dashboard.empty.EmptyFragment;
import ir.i3p.freight.ui.dashboard.profile.ProfileFragment;
import ir.i3p.freight.ui.dashboard.shop.ShopFragment;


/**
 * Created by m.hejazi on 5/14/18.
 */

public class DashboarNavigator implements BaseNavigator<DashboardActivity> {
    private final WeakReference<DashboardActivity> mActivity;

    public DashboarNavigator(DashboardActivity activity) {
        mActivity = new WeakReference<>(activity);
    }

    public void openEmptyFragment(String title) {
        try {
            getSFragmentTransaction()
                    .replace(R.id.dashboarContainer, EmptyFragment.newInstance(title))
                    .commitAllowingStateLoss();
        } catch (Throwable throwable) {
            throwable.printStackTrace();
        }
    }

    public void openShopFragment(boolean isMyShop) {
        try {
            getSFragmentTransaction()
                    .replace(R.id.dashboarContainer, ShopFragment.newInstance(isMyShop), isMyShop ? "myShop" : "market")
                    .commitAllowingStateLoss();
        } catch (Throwable throwable) {
            throwable.printStackTrace();
        }
    }

    public void openMyAccountFragment() {
        try {
            getSFragmentTransaction()
                    .replace(R.id.dashboarContainer, null)
                    .commitAllowingStateLoss();
        } catch (Throwable throwable) {
            throwable.printStackTrace();
        }
    }

    public void openProfileFragment() {
        try {
            getSFragmentTransaction()
                    .replace(R.id.dashboarContainer, ProfileFragment.newInstance())
                    .commitAllowingStateLoss();
        } catch (Throwable throwable) {
            throwable.printStackTrace();
        }
    }

    public void openMainActivity() {
        // TODO: 3/10/18 user logged in so we should open main activity
        finishActivity();
    }

    @Override
    public WeakReference<DashboardActivity> getActivity() {
        return mActivity;
    }
}
