package ir.smh.kotlinmvvmtest.ui.shopproduct;

import android.databinding.DataBindingUtil;
import android.os.Bundle;

import com.ppp_smh.initlibrary.ui.base.BaseActivity;

import javax.inject.Inject;

import ir.i3p.freight.R;
import ir.i3p.freight.data.model.shop.ResponseProductModel;
import ir.i3p.freight.databinding.ActivityShopProductBinding;

public class ShopProductActivity extends BaseActivity<ShopProductVM> {

    public static final String KEY_EXTRA_PRODUCT = "product_key";
    ResponseProductModel responseProductModel;
    @Inject
    ShopProductVM mViewModel;
    private ActivityShopProductBinding activityShopProductBinding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activityShopProductBinding = DataBindingUtil.setContentView(this, R.layout.activity_shop_product);
        activityShopProductBinding.setViewModel(mViewModel);
//        mViewModel.getUser(getIntent().getExtras().getInt(KEY_EXTRA_PRODUCT));
        mViewModel.setProduct(getIntent().getExtras().getParcelable(KEY_EXTRA_PRODUCT));
        mViewModel.setShowActionHome(true);
        setContentView(activityShopProductBinding.getRoot());
        setBaseVM(mViewModel);

    }

    @Override
    protected void onResume() {
        super.onResume();
//        mViewModel.imagesArray.observe(this, this::showImages);
    }

    /*private void showImages(String[] images) {
        activityShopProductBinding.imageViewPager.setImageUrls(images, new ImageURLLoader() {
            @Override
            public void loadImage(ImageView view, String url) {
                Picasso.get().load(url).into(view);
            }
        });
        int indicatorColor = Color.parseColor("#ffffff");
        int selectedIndicatorColor = Color.parseColor("#000000");
        activityShopProductBinding.imageViewPager.showIndicator(indicatorColor, selectedIndicatorColor);
    }*/

    @Override
    public ShopProductVM getViewModel() {
        return mViewModel;
    }
}
