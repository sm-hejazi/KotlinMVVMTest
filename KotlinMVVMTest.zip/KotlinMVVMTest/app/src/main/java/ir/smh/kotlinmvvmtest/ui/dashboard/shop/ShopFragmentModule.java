package ir.smh.kotlinmvvmtest.ui.dashboard.shop;

import dagger.Module;
import dagger.Provides;
import ir.i3p.freight.data.local.preference.AppPreferencesHelper;
import ir.i3p.freight.data.repository.dashboard.shop.MyShopRepository;
import ir.i3p.freight.data.repository.dashboard.shop.MyShopRepositoryFactory;
import ir.i3p.freight.data.repository.dashboard.shop.MyShopRepositoryImpl;
import ir.i3p.freight.data.repository.dashboard.shop.shopproduct.ShopProductRepository;
import ir.i3p.freight.data.repository.dashboard.shop.shopproduct.ShopProductRepositoryFactory;
import ir.i3p.freight.data.repository.dashboard.shop.shopproduct.ShopProductRepositoryImpl;

/**
 * Created by m.hejazi on 5/14/18.
 */
@Module
public class ShopFragmentModule {

    @Provides
    MyShopRepository provideUserRepository(MyShopRepositoryFactory myShopRepositoryFactory, AppPreferencesHelper appPreferencesHelper) {
        return new MyShopRepositoryImpl(myShopRepositoryFactory, appPreferencesHelper);
    }

    @Provides
    ShopProductRepository provideShopProductRepository(ShopProductRepositoryFactory shopProductRepositoryFactory) {
        return new ShopProductRepositoryImpl(shopProductRepositoryFactory);
    }
}
