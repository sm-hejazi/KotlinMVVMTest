package ir.smh.kotlinmvvmtest.ui.shopproduct;

import com.ppp_smh.initlibrary.util.navigator.BaseNavigator;

import java.lang.ref.WeakReference;


/**
 * Created by m.hejazi on 5/14/18.
 */

public class ShopProductNavigator implements BaseNavigator<ShopProductActivity> {
    private final WeakReference<ShopProductActivity> mActivity;

    public ShopProductNavigator(ShopProductActivity activity) {
        mActivity = new WeakReference<>(activity);
    }


    @Override
    public WeakReference<ShopProductActivity> getActivity() {
        return mActivity;
    }
}
