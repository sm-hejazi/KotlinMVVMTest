package ir.smh.kotlinmvvmtest.ui.dashboard.shop;

import android.content.DialogInterface;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import androidx.appcompat.app.AlertDialog;

import com.ppp_smh.initlibrary.ui.base.BaseActivity;
import com.ppp_smh.initlibrary.ui.base.BaseFragment;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import ir.i3p.freight.R;
import ir.i3p.freight.data.model.enumType.ProductAddEditStatus;
import ir.i3p.freight.data.model.shop.CargoModel;
import ir.i3p.freight.data.model.shop.Filter;
import ir.i3p.freight.databinding.FragmentMyshopBinding;
import ir.i3p.freight.ui.addeditproduct.AddEditProductActivity;
import ir.i3p.freight.ui.dashboard.DashboardActivity;
import ir.i3p.freight.ui.dashboard.shop.list.ShopAdapter;
import ir.i3p.freight.ui.filter.FilterActivity;
import ir.i3p.freight.ui.shopproduct.ShopProductActivity;

import static androidx.appcompat.app.AppCompatActivity.RESULT_OK;

public class ShopFragment extends BaseFragment<ShopVM> {
    private FragmentMyshopBinding binding;
    private ShopAdapter shopAdapter;
    private boolean isMyShop;

    @Inject
    ShopVM mViewModel;

    public static ShopFragment newInstance(boolean isMyShop) {
        Bundle args = new Bundle();
        ShopFragment fragment = new ShopFragment();
        fragment.isMyShop = isMyShop;
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_myshop, container, false);
        binding.setViewModel(mViewModel);
        ((BaseActivity) getActivity()).setBaseVM(mViewModel);
        shopAdapter = new ShopAdapter(mViewModel, isMyShop);
        binding.products.setLayoutManager(new LinearLayoutManager(getActivity()));
        binding.products.setAdapter(shopAdapter);
        mViewModel.getProducts(0, isMyShop);
        return binding.getRoot();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == RESULT_OK && requestCode == AddEditProductActivity.REQUEST_CODE_ADD) {
            CargoModel cargoAdd = data.getParcelableExtra(AddEditProductActivity.KEY_EXTRA_PRODUCT);
            refreshList(cargoAdd, ProductAddEditStatus.ADD);
        } else if (resultCode == RESULT_OK && requestCode == AddEditProductActivity.REQUEST_CODE_EDIT) {
            CargoModel cargoEdited = data.getParcelableExtra(AddEditProductActivity.KEY_EXTRA_PRODUCT);
            refreshList(cargoEdited, ProductAddEditStatus.UPDATE);
        } else if (resultCode == RESULT_OK && requestCode == FilterActivity.RQUEST_CODE_FILTER) {
            Filter filter = data.getParcelableExtra(FilterActivity.KEY_EXTRA_FILTER);
            mViewModel.getProductFilter(0, filter);
        }
    }

    private void refreshList(CargoModel cargoModel,String state) {
        cargoModel.setPostageDate(postageDateOk(cargoModel.getPostageDate()));
        List<CargoModel> cargoModels = new ArrayList<>();
        cargoModels.add(cargoModel);
        mViewModel.setProductModels(cargoModels,state);
    }

    private String postageDateOk(String date) {
        String dateArr[] = date.split("-");
        return dateArr[0] + "/" + dateArr[1] + "/" + dateArr[2] + "  " + dateArr[3] + ":" + dateArr[4] + ":" + dateArr[5];
    }

    public void onActionClick(MenuItem item) {
        mViewModel.onActionClick(item);
    }

    @Override
    public void onResume() {
        super.onResume();
    }


    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mViewModel.raisedError.observe(this, this::showError);
        mViewModel.confirmDelete.observe(this, this::deleteDialog);
        mViewModel.pageTitel.observe(this, this::setTitle);
        mViewModel.startEditActivity.observe(this, this::startAddEditActivityFR);
        mViewModel.startFilterActivity.observe(this, this::startFilterActivityFR);

        mViewModel.setIsMyShop(isMyShop);
        if (isMyShop) {
            mViewModel.setShowActionSearch(false);
            mViewModel.setShowActonFilter(false);
        } else {
            mViewModel.setShowActionSearch(false);//TODO temp
            mViewModel.setShowActonFilter(false);
        }
        ((DashboardActivity) getActivity()).updateActionMenu(null);
        setTitle("");
    }

    private void setTitle(String title) {
        if (isMyShop)
            getActivity().setTitle(getString(R.string.title_my));
        else
            getActivity().setTitle(getString(R.string.title_all));

    }

    private void startAddEditActivityFR(CargoModel cargoModel) {
        Intent intent = new Intent(getActivity(), AddEditProductActivity.class);
        int resultCode = AddEditProductActivity.REQUEST_CODE_ADD;
        if (cargoModel != null) {
            intent.putExtra(ShopProductActivity.KEY_EXTRA_PRODUCT, cargoModel);
            resultCode = AddEditProductActivity.REQUEST_CODE_EDIT;
        }
        startActivityForResult(intent, resultCode);
    }

    private void startFilterActivityFR(Filter filter) {
        Intent intent = new Intent(getActivity(), FilterActivity.class);
        if (filter != null)
            intent.putExtra(FilterActivity.KEY_EXTRA_FILTER, filter);
        startActivityForResult(intent, FilterActivity.RQUEST_CODE_FILTER);
    }


    private void deleteDialog(CargoModel product) {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(getActivity());
        alertDialog.setTitle(getString(R.string.delete));
        alertDialog.setMessage(String.format(getString(R.string.message_delete), product.getGoodsName()));
        alertDialog.setPositiveButton(getString(com.ppp_smh.initlibrary.R.string.yes), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                mViewModel.deleteProduct(product);
            }
        });

        // On pressing the cancel button
        alertDialog.setNegativeButton(getString(com.ppp_smh.initlibrary.R.string.cancel), new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        alertDialog.show();
    }

    @Override
    public ShopVM getViewModel() {
        return mViewModel;
    }

}
