package ir.smh.kotlinmvvmtest.ui.dashboard;

import com.ppp_smh.initlibrary.ui.base.BaseViewModel;
import com.ppp_smh.initlibrary.util.connectivity.BaseConnectionManager;

import javax.inject.Inject;

import ir.i3p.freight.ui.addeditproduct.AddEditProductActivity;


/**
 * Created by m.hejazi on 5/14/18.
 */

@SuppressWarnings({"ALL", "unchecked"})
public class DashboardVM extends BaseViewModel {
    private final DashboarNavigator dashboarNavigator;

    @Inject
    public DashboardVM(BaseConnectionManager connectionManager, DashboarNavigator dashboarNavigator) {
        super(connectionManager, dashboarNavigator);
        this.dashboarNavigator = dashboarNavigator;
    }

    public void openShop(boolean isMyShop) {
        dashboarNavigator.openShopFragment(isMyShop);
    }

    public void addProduct() {
        dashboarNavigator.startActivity(AddEditProductActivity.class);
    }

    public void openEmpty(String title) {
        dashboarNavigator.openEmptyFragment(title);
    }

    public void openMyAccount() {
        dashboarNavigator.openMyAccountFragment();
    }

    public void openProfile() {
        dashboarNavigator.openProfileFragment();
    }

    public <T> T getCurrentFragment(String tag){
        try {
            return (T) dashboarNavigator.getFragmentManager().findFragmentByTag(tag);
        } catch (Throwable throwable) {
            throwable.printStackTrace();
        }
        return null;
    }

    @Override
    public void onClear() {
        super.onClear();
    }

    @Override
    public void clearUseCaseDisposables() {

    }
}
