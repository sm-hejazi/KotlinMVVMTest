package ir.smh.kotlinmvvmtest.ui.dashboard.empty;

import dagger.Module;
import dagger.Provides;
import ir.i3p.freight.data.local.preference.AppPreferencesHelper;
import ir.i3p.freight.data.repository.dashboard.shop.MyShopRepository;
import ir.i3p.freight.data.repository.dashboard.shop.MyShopRepositoryFactory;
import ir.i3p.freight.data.repository.dashboard.shop.MyShopRepositoryImpl;

/**
 * Created by m.hejazi on 5/14/18.
 */
@Module
public class EmptyFragmentModule {


    @Provides
    MyShopRepository provideUserRepository(MyShopRepositoryFactory myShopRepositoryFactory, AppPreferencesHelper appPreferencesHelper) {
        return new MyShopRepositoryImpl(myShopRepositoryFactory, appPreferencesHelper);
    }
}
