package ir.smh.kotlinmvvmtest.ui.shopproduct;

import dagger.Module;
import dagger.Provides;
import ir.i3p.freight.data.repository.dashboard.shop.shopproduct.ShopProductRepository;
import ir.i3p.freight.data.repository.dashboard.shop.shopproduct.ShopProductRepositoryFactory;
import ir.i3p.freight.data.repository.dashboard.shop.shopproduct.ShopProductRepositoryImpl;
import ir.i3p.freight.di.scope.ActivityScope;

/**
 * Created by m.hejazi on 5/14/18.
 */
@Module
public class ShopProductActivityModule {

    @Provides
    @ActivityScope
    public ShopProductNavigator provideNavigator(ShopProductActivity shopProductActivity) {
        return new ShopProductNavigator(shopProductActivity);
    }

    @Provides
    ShopProductRepository provideShopProductRepository(ShopProductRepositoryFactory repositoryFactory) {
        return new ShopProductRepositoryImpl(repositoryFactory);
    }
}
