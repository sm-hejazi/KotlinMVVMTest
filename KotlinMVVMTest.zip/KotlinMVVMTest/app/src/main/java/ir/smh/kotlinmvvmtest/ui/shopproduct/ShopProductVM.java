package ir.smh.kotlinmvvmtest.ui.shopproduct;

import android.databinding.ObservableBoolean;
import android.databinding.ObservableField;

import com.ppp_smh.initlibrary.entity.ErrorStatus.ErrorModel;
import com.ppp_smh.initlibrary.ui.base.BaseViewModel;
import com.ppp_smh.initlibrary.ui.base.SingleEventLiveData;
import com.ppp_smh.initlibrary.util.connectivity.BaseConnectionManager;

import java.util.HashMap;

import javax.inject.Inject;

import ir.i3p.freight.call.dashboard.shop.ShopProductUseCase;
import ir.i3p.freight.data.model.shop.CargoModel;
import ir.i3p.freight.util.CSVReader;

public class ShopProductVM extends BaseViewModel {
    private final SingleEventLiveData<ErrorModel> raisedError;
//    final SingleEventLiveData<String[]> imagesArray;
    //    private ObservableBoolean isLoading;
    private final ShopProductUseCase shopProductUseCase;
    private final ObservableField<CargoModel> product;

    private HashMap<Integer,String> cityMap;
    private HashMap<Integer,String> stateMap;
    private HashMap<Integer,String> truckMap;
    private HashMap<Integer,String> packingMap;

    @Inject
    public ShopProductVM(BaseConnectionManager connectionManager, ShopProductNavigator shopProductNavigator, ShopProductUseCase shopProductUseCase) {
        super(connectionManager, shopProductNavigator);
        ShopProductNavigator shopProductNavigator1 = shopProductNavigator;
        this.shopProductUseCase = shopProductUseCase;
//        isLoading = new ObservableBoolean(false);
        raisedError = new SingleEventLiveData<>();
//        imagesArray = new SingleEventLiveData<>();
        product = new ObservableField<>();

        cityMap = new CSVReader().readMap("data_file/city.csv");
        stateMap = new CSVReader().readMap("data_file/state.csv");
        truckMap = new CSVReader().readMap("data_file/truck.csv");
        packingMap = new CSVReader().readMap("data_file/packing.csv");
    }

   /* public void getUser(Integer id) {
        isLoading.set(true);
        shopProductUseCase
                .setParameters(id)
                .execute(this::requestShopProductResponse, this::onTokenExpired);
    }

    private void requestShopProductResponse(Pair<CargoModel, ErrorModel> response) {
        isLoading.set(false);
        if (response.second != null) {
            raisedError.setValue(response.second);
            return;
        }
        if (response.first != null && response.first != null) {
            setUser(response.first);

//            String[] demoUrlArray = new String[]{
//                    "https://www.gardenhousepalermo.com/wp-content/uploads/2015/10/P-Oxford_Cognac22x90cm-Liston-Oxford_Cognac316x90cm.jpg",
//                    "https://persianagahi.com/sites/default/files/styles/flexslider_full/public/ad_files/I380X300_087570802790_0.jpg?itok=xxx7nagd",
//                    "http://ariyazon.com/wp-content/uploads/2015/12/forb-17.jpg"
//            };
//            imagesArray.setValue(demoUrlArray);
//            imagesArray.setValue(getImages(response.first.getProductImageList()));
        }
    }*/

    /*private String[] getImages(List<ImageModel> list) {
        String[] array = new String[list.size()];
        for (int i = 0; i < list.size(); i++) {
            array[i] = BuildConfig.BASE_URL_IMG + list.get(i).getImage();
        }
        return array;
    }*/

    @Override
    public void clearUseCaseDisposables() {
        shopProductUseCase.dispose();
    }

    public ObservableBoolean getIsLoading() {
        return isLoading;
    }

    public ObservableField<CargoModel> getProduct() {
        return product;
    }

    public void setProduct(CargoModel product) {
        product.setSource(stateMap.get(product.getFirstOstanCId()) + " - " + cityMap.get(product.getFirstCityCId()));
        product.setDestination(stateMap.get(product.getLastOstanCId())  + " - " + cityMap.get(product.getLastCityCId()));
        product.setTruckType(truckMap.get(product.getCarTypeCint()));
        product.setPackingType(packingMap.get(product.getPakingCId()));
        this.product.set(product);
    }

}
