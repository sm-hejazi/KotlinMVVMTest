package ir.smh.kotlinmvvmtest.ui.dashboard.shop;

import android.databinding.ObservableArrayList;
import android.databinding.ObservableBoolean;
import android.databinding.ObservableField;
import android.databinding.ObservableList;
import android.os.Bundle;
import android.support.v4.util.Pair;
import android.view.MenuItem;
import android.widget.CompoundButton;

import com.ppp_smh.initlibrary.entity.ErrorStatus.ErrorModel;
import com.ppp_smh.initlibrary.ui.base.BaseViewModel;
import com.ppp_smh.initlibrary.ui.base.SingleEventLiveData;
import com.ppp_smh.initlibrary.util.connectivity.BaseConnectionManager;

import java.util.List;

import javax.inject.Inject;

import ir.i3p.freight.R;
import ir.i3p.freight.call.dashboard.shop.DeleteProductUseCase;
import ir.i3p.freight.call.dashboard.shop.MyShopUseCase;
import ir.i3p.freight.call.dashboard.shop.ShopProductExistUseCase;
import ir.i3p.freight.data.model.enumType.ProductAddEditStatus;
import ir.i3p.freight.data.model.shop.CargoModel;
import ir.i3p.freight.data.model.shop.Filter;
import ir.i3p.freight.ui.dashboard.DashboarNavigator;
import ir.i3p.freight.ui.shopproduct.ShopProductActivity;

/**
 * Created by m.hejazi on 5/14/18.
 */

public class ShopVM extends BaseViewModel {
    private final static String TAG = ShopVM.class.getSimpleName();
    SingleEventLiveData<ErrorModel> raisedError;
    SingleEventLiveData<CargoModel> confirmDelete;
    SingleEventLiveData<String> pageTitel;
    SingleEventLiveData<CargoModel> startEditActivity;
    SingleEventLiveData<Filter> startFilterActivity;
    private DashboarNavigator dashboarNavigator;
    private MyShopUseCase myShopUseCase;
    private ShopProductExistUseCase shopProductExistUseCase;
    private DeleteProductUseCase deleteProductUseCase;
    private ObservableList<CargoModel> responseProductModels;
    private ObservableBoolean isMyShop = new ObservableBoolean(false);
    private ObservableBoolean errService = new ObservableBoolean(false);
    private ObservableField<String> productState = new ObservableField<>(ProductAddEditStatus.CHANGE_LIST);
    private CompoundButton existSwitch;

    private Filter filter = new Filter();

    @Inject
    public ShopVM(BaseConnectionManager connectionManager, DashboarNavigator dashboarNavigator, MyShopUseCase myShopUseCase, ShopProductExistUseCase shopProductExistUseCase, DeleteProductUseCase deleteProductUseCase) {
        super(connectionManager, dashboarNavigator);
        this.dashboarNavigator = dashboarNavigator;
        this.myShopUseCase = myShopUseCase;
        this.shopProductExistUseCase = shopProductExistUseCase;
        this.deleteProductUseCase = deleteProductUseCase;
        raisedError = new SingleEventLiveData<>();
        confirmDelete = new SingleEventLiveData<>();
        pageTitel = new SingleEventLiveData<>();
        startEditActivity = new SingleEventLiveData<>();
        startFilterActivity = new SingleEventLiveData<>();
        responseProductModels = new ObservableArrayList<>();
    }

    public void getProducts(Integer pageNumber, boolean isMyShop) {
        if (pageNumber == 0)
            isLoading.set(true);
        else
            isLoadingBg.set(true);
        myShopUseCase
                .setParameters(pageNumber, isMyShop, false, null)
                .execute(this::requestShopResponse, this::onTokenExpired);
    }

    public void requestShopResponse(Pair<List<CargoModel>, ErrorModel> response) {
        isLoading.set(false);
        isLoadingBg.set(false);
        if (response.second != null) {
            if (response.second.getCode() == -1) errService.set(true);
            raisedError.setValue(response.second);
            return;
        }

        if (response.first != null && response.first.size() > 0) {
            setProductModels(response.first, ProductAddEditStatus.CHANGE_LIST);
        }
    }

    public void getProductFilter(int pageNumber, Filter filter) {
        this.filter = filter;
        isLoading.set(true);
        myShopUseCase
                .setParameters(pageNumber, false, true, filter)
                .execute(this::requestShopResponse, this::onTokenExpired);
    }

    public void detailProduct(CargoModel product) {
        Bundle bundle = new Bundle();
        bundle.putParcelable(ShopProductActivity.KEY_EXTRA_PRODUCT, product);
        dashboarNavigator.startActivity(ShopProductActivity.class, bundle);
    }

    public void updateProductExist(CompoundButton compoundButton, Integer id, boolean b) {
        isLoading.set(true);
        existSwitch = compoundButton;
        shopProductExistUseCase
                .setParameters(id, b ? 1 : 0)
                .execute(this::updateProductExistResponse, this::onTokenExpiredInVM);
    }

    private void onTokenExpiredInVM(Class aClass) {
        existSwitch.setChecked(!existSwitch.isChecked());
        onTokenExpired(aClass);
    }


    private void updateProductExistResponse(Pair<Void, ErrorModel> response) {
        isLoading.set(false);
        if (response.second != null) {
            existSwitch.setChecked(!existSwitch.isChecked());
            raisedError.setValue(response.second);
            return;
        }
    }

    private CargoModel currentDeleteProduct;

    public void deleteProduct(CargoModel product) {
        currentDeleteProduct = product;
        isLoading.set(true);
        deleteProductUseCase
                .setParameters(product.getId())
                .execute(this::deleteProductResponse, this::onTokenExpiredInVM);
    }

    private void deleteProductResponse(Pair<Void, ErrorModel> response) {
        isLoading.set(false);
        if (response.second != null) {
            raisedError.setValue(response.second);
            return;
        }

        responseProductModels.remove(currentDeleteProduct);
//        getProducts(1, ); //Recreate recycler view list
    }

//    public void showPopUpMenu(ProductItemBinding itemLayoutBinding, ShopAdapter shopAdapter, CargoModel product) {
//        this.shopAdapter = shopAdapter;
//        PopupMenu popup = new PopupMenu(itemLayoutBinding.getRoot().getContext(), itemLayoutBinding.optionMenu);
//        popup.inflate(R.menu.item_menu);
//        setForceShowIcon(popup);
//        popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
//            @Override
//            public boolean onMenuItemClick(MenuItem item) {
//                switch (item.getItemId()) {
//                    case R.id.edit:
//                        startEditActivity.setValue(product.getId());
//                        return true;
//                    case R.id.delete:
//                        confirmDelete.setValue(product);
//                        return true;
//                    default:
//                        return false;
//                }
//            }
//        });
//        //displaying the popup
//        popup.show();
//    }

    @Override
    public void clearUseCaseDisposables() {
        myShopUseCase.dispose();
    }

    public ObservableBoolean getIsLoading() {
        return isLoading;
    }

    public ObservableList<CargoModel> getResponseProductModels() {
        return responseProductModels;
    }

    public void setProductModels(List<CargoModel> cargoModels, String productState ) {
        this.productState.set(productState);
        responseProductModels.clear();
        responseProductModels.addAll(cargoModels);
    }

    /*private void setForceShowIcon(PopupMenu popupMenu) {
        try {
            Field[] fields = popupMenu.getClass().getDeclaredFields();
            for (Field field : fields) {
                if ("mPopup".equals(field.getName())) {
                    field.setAccessible(true);
                    Object menuPopupHelper = field.get(popupMenu);
                    Class<?> classPopupHelper = Class.forName(menuPopupHelper
                            .getClass().getName());
                    Method setForceIcons = classPopupHelper.getMethod(
                            "setForceShowIcon", boolean.class);
                    setForceIcons.invoke(menuPopupHelper, true);
                    break;
                }
            }
        } catch (Throwable e) {
            e.printStackTrace();
        }
    }*/

    public void addProduct() {
        startEditActivity.setValue(null);
    }

    public ObservableBoolean getIsMyShop() {
        return isMyShop;
    }

    public void setIsMyShop(boolean isMyShop) {
        this.isMyShop.set(isMyShop);
    }

    public void onActionClick(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_filter) {
            startFilterActivity.setValue(filter);
        }
    }

    public Filter getFilter() {
        return filter;
    }

    public void setFilter(Filter filter) {
        this.filter = filter;
    }

    public void repeatCargo(CargoModel cargoModel) {
        startEditActivity.setValue(cargoModel);
    }

    public void editCargo(CargoModel cargoModel) {
        startEditActivity.setValue(cargoModel);
    }

    public void removeCargo(CargoModel cargoModel) {
        confirmDelete.setValue(cargoModel);
    }

    public void onLoadMore(int page){
        getProducts(page,isMyShop.get());
    }

    public ObservableBoolean getErrService() {
        return errService;
    }

    public ObservableField<String> getProductState() {
        return productState;
    }
}
