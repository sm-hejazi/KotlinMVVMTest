package ir.smh.kotlinmvvmtest.ui.dashboard.empty;

import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.ppp_smh.initlibrary.ui.base.BaseActivity;
import com.ppp_smh.initlibrary.ui.base.BaseFragment;

import javax.inject.Inject;

import ir.i3p.freight.R;
import ir.i3p.freight.databinding.FragmentMarketBinding;


public class EmptyFragment extends BaseFragment<EmptyVM> {


    @Inject
    EmptyVM mViewModel;

    private String title;

    public EmptyFragment() {
        // Required empty public constructor
    }


    public static EmptyFragment newInstance(String title) {
        EmptyFragment fragment = new EmptyFragment();
        fragment.title = title;
//        Bundle args = new Bundle();
//        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        FragmentMarketBinding binding = DataBindingUtil.inflate(inflater,R.layout.fragment_market,container,false);
        binding.setViewModel(mViewModel);
        ((BaseActivity)getActivity()).setBaseVM(mViewModel);
        getActivity().setTitle(title);
        return inflater.inflate(R.layout.fragment_market, container, false);
    }

    @Override
    public EmptyVM getViewModel() {
        return mViewModel;
    }
}
