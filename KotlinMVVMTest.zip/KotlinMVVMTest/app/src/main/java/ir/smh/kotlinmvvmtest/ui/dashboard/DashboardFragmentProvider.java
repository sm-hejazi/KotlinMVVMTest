package ir.smh.kotlinmvvmtest.ui.dashboard;


import dagger.Module;
import dagger.android.ContributesAndroidInjector;
import ir.i3p.freight.ui.dashboard.empty.EmptyFragment;
import ir.i3p.freight.ui.dashboard.empty.EmptyFragmentModule;
import ir.i3p.freight.ui.dashboard.profile.ProfileFragment;
import ir.i3p.freight.ui.dashboard.profile.ProfileFragmentModule;
import ir.i3p.freight.ui.dashboard.shop.ShopFragment;
import ir.i3p.freight.ui.dashboard.shop.ShopFragmentModule;

/**
 * Created by m.hejazi on 5/14/18.
 */
@Module
public abstract class DashboardFragmentProvider {

    @ContributesAndroidInjector(modules = ShopFragmentModule.class)
    public abstract ShopFragment provideMyShopFragment();

    @ContributesAndroidInjector(modules = EmptyFragmentModule.class)
    public abstract EmptyFragment provideMarketFragment();
    //

    @ContributesAndroidInjector(modules = ProfileFragmentModule.class)
    public abstract ProfileFragment provideProfileFragment();

}
