package ir.smh.kotlinmvvmtest.ui.dashboard.empty;

import android.databinding.ObservableBoolean;
import android.support.v4.util.Pair;

import com.ppp_smh.initlibrary.entity.ErrorStatus.ErrorModel;
import com.ppp_smh.initlibrary.ui.base.BaseViewModel;
import com.ppp_smh.initlibrary.ui.base.SingleEventLiveData;
import com.ppp_smh.initlibrary.util.connectivity.BaseConnectionManager;

import javax.inject.Inject;

import ir.i3p.freight.call.dashboard.shop.MyShopUseCase;
import ir.i3p.freight.data.model.shop.ResponseShopItemsModel;
import ir.i3p.freight.ui.dashboard.DashboarNavigator;


/**
 * Created by m.hejazi on 5/14/18.
 */

public class EmptyVM extends BaseViewModel {
    private final SingleEventLiveData<ErrorModel> raisedError;
    private final MyShopUseCase mUseCase;
//    private ObservableField<Wave> loadingDoubleBounce;

    @Inject
    public EmptyVM(BaseConnectionManager connectionManager, DashboarNavigator mNavigator, MyShopUseCase mUseCase) {
        super(connectionManager, mNavigator);
        DashboarNavigator mNavigator1 = mNavigator;
        this.mUseCase = mUseCase;
        raisedError = new SingleEventLiveData<>();
    }

//    public void getMarket() {
//        isLoading.set(true);
//        mUseCase.setParameters(1,false)
//                .execute(this::requestMarketResponse, this::onTokenExpired);
//    }

    private void requestMarketResponse(Pair<ResponseShopItemsModel, ErrorModel> response) {
        isLoading.set(false);
        if (response.second != null) {
            raisedError.setValue(response.second);
            return;
        }
    }

    @Override
    public void clearUseCaseDisposables() {
        mUseCase.dispose();
    }

    public ObservableBoolean getIsLoading() {
        return isLoading;
    }

}
