package ir.smh.kotlinmvvmtest.ui.dashboard.shop.list;

import android.databinding.BindingAdapter;
import android.support.v7.widget.RecyclerView;

import java.util.List;

import ir.i3p.freight.data.model.enumType.ProductAddEditStatus;
import ir.i3p.freight.data.model.shop.CargoModel;
import ir.i3p.freight.util.recycleViewScroll.RecyclerViewScrollCallback;

public class ProductListBinding {

    @BindingAdapter(value = {"products", "onState"}, requireAll = false)
    public static void setProducts(RecyclerView recyclerView,
                                   List<CargoModel> cargoModels, String onState) {
        RecyclerView.Adapter adapter = recyclerView.getAdapter();

        //check if adapter object isn't null and is from PersonAdapter
        if (adapter != null && adapter instanceof ShopAdapter) {
            if (onState.equals(ProductAddEditStatus.ADD))
                ((ShopAdapter) adapter).addNewProduct(cargoModels);
            else if (onState.equals(ProductAddEditStatus.UPDATE))
                ((ShopAdapter) adapter).updateProduct(cargoModels);
            else
                ((ShopAdapter) adapter).addMoreProducts(cargoModels);
        } else
            throw new IllegalStateException("RecyclerView either" +
                    " has no adapter set or the "
                    + "adapter isn't of type MovieAdapter");
    }

    /**
     * @param recyclerView       RecyclerView to bind to RecyclerViewScrollCallback
     * @param visibleThreshold   The minimum number of items to have below your current scroll position before loading more.
     * @param resetLoadingState  Reset endless scroll listener when performing a new search
     * @param onScrolledListener OnScrolledListener for RecyclerView scrolled
     */
    @BindingAdapter(value = {"visibleThreshold", "resetLoadingState", "onScrolledToBottom"}, requireAll = false)
    public static void setRecyclerViewScrollCallback(RecyclerView recyclerView, int visibleThreshold, Boolean resetLoadingState,
                                                     RecyclerViewScrollCallback.OnScrolledListener onScrolledListener) {

        RecyclerViewScrollCallback callback = new RecyclerViewScrollCallback
                .Builder(recyclerView.getLayoutManager())
                .visibleThreshold(visibleThreshold)
                .onScrolledListener(onScrolledListener)
                .resetLoadingState(resetLoadingState)
                .build();

        recyclerView.clearOnScrollListeners();
        recyclerView.addOnScrollListener(callback);
    }
}
