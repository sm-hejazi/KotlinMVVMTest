package ir.smh.kotlinmvvmtest.ui.dashboard.profile;

import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.ppp_smh.initlibrary.ui.base.BaseActivity;
import com.ppp_smh.initlibrary.ui.base.BaseFragment;

import javax.inject.Inject;

import ir.i3p.freight.R;
import ir.i3p.freight.data.model.user.UserModel;
import ir.i3p.freight.databinding.FragmentProfileBinding;
import ir.i3p.freight.ui.profileEdit.ProfileEditActivity;


public class ProfileFragment extends BaseFragment<ProfileVM> {


    @Inject
    ProfileVM mViewModel;

    public ProfileFragment() {
        // Required empty public constructor
    }


    public static ProfileFragment newInstance() {
        ProfileFragment fragment = new ProfileFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        FragmentProfileBinding binding = DataBindingUtil.inflate(inflater,R.layout.fragment_profile,container,false);

        mViewModel.raisedError.observe(this, this::showError);
        mViewModel.startEditActivity.observe(this, this::startAddEditActivityFR);

        binding.setViewModel(mViewModel);
        mViewModel.getUserWeb();
        ((BaseActivity)getActivity()).setBaseVM(mViewModel);
        getActivity().setTitle(getString(R.string.nav_profile));
        return binding.getRoot();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == ProfileEditActivity.REQUEST_CODE_USER_EDIT) {
            if (data != null && data.getExtras() != null && data.getExtras().containsKey(ProfileEditActivity.KEY_EXTRA_USER))
                mViewModel.setUser(data.getExtras().getParcelable(ProfileEditActivity.KEY_EXTRA_USER));
        }
    }

    @Override
    public ProfileVM getViewModel() {
        return mViewModel;
    }

    private void startAddEditActivityFR(UserModel userModel) {
        Intent intent = new Intent(getActivity(), ProfileEditActivity.class);
        if (userModel != null)
            intent.putExtra(ProfileEditActivity.KEY_EXTRA_USER, userModel);
        startActivityForResult(intent, ProfileEditActivity.REQUEST_CODE_USER_EDIT);
    }
}
